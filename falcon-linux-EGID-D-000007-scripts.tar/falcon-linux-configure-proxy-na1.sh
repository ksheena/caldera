#!/bin/bash

if  ! [ -x "/opt/CrowdStrike/falconctl" ]; then
    echo "Crowdstrike Falcon package is not installed properly"
    exit 1
fi

echo "configure Crowdstrike falcon sensor"
/opt/CrowdStrike/falconctl -s -f --cid="8D1D0162E794458180D9091E71BA686F-30" --tags="EGID-D-000007" --aph="svr001-na1-svr.zone1.proxy.allianz" --app="8090" --apd="false"
if [ "$?" -ne "0" ] ;then
    echo "CrowdStrike Config failed"
    exit 2
fi

echo "Start Crowdstrike"

service falcon-sensor restart
if [ "$?" -ne "0" ] ;then
   echo "no SysVinit, trying Systemd"
   systemctl restart falcon-sensor
   if [ "$?" -ne "0" ] ;then
      "no Systemd, Falcon Sensor not started"
      exit 3
   fi
fi

echo "Crowdstrike Falcon Sensor successfully started"
